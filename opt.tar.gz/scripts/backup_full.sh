#!/bin/bash

if [[ $# -lt 2 || $1 == "-help" ]]; then
	echo "$0 <origen> <destino>"
	exit 0
fi

if [[ ! -d "$1" ]]; then
	echo "El directorio de origen no existe"
	exit 0
fi

if [[ ! -d "$2" ]]; then
	echo "El directorio de destino no existe"
	exit 0
fi

FECHA=$(date +%Y%m%d)

BACKUP=$(basename "$1")_bkp_$FECHA.tar.gz

tar -czf "$2/$BACKUP" -C "$1" .

if [[ $? == 0 ]]; then
	echo "Backup exitoso"
fi
